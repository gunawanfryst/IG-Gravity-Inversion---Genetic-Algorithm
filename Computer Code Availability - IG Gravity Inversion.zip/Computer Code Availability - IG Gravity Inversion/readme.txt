 Name of code   : IG Gravity Inversion - Genetic Algorithm
 Version        : 1.7.3
 Developer      : Indra Gunawan
 Contact        : Teknik Geofisika, Institut Teknologi Bandung, Jl. Ganesha 10, BSC-B building, 2nd Floor, Dago, Bandung, Indonesia - 40132
 Phone          : (+62)853-551-88014 
 Email          : gunawan@geoph.itb.ac.id, gunawan.geoph@gmail.com
 Code Available : 01-01-2017  
 Manuscript number : CAGEO_2019_115 (Computers and Geosciences)
 Title 		   : An application and annotation of the genetic algorithm inversion for subsurface modeling using surface and borehole time-lapse gravity