﻿/*
 Name of code   : IG Gravity Inversion - Genetic Algorithm
 Version        : 1.7.3
 Developer      : Indra Gunawan
 Contact        : Teknik Geofisika, Institut Teknologi Bandung, Jl. Ganesha 10, BSC-B building, 2nd Floor, Dago, Bandung, Indonesia - 40132
 Phone          : (+62)853-551-88014 
 Email          : gunawan@geoph.itb.ac.id, gunawan.geoph@gmail.com
 Code Available : 01-01-2017  
 */

using System;
using System.Windows.Forms;

namespace IG
{
    public partial class MainForm : Form
    {
        private GIMForm GIM_Form;

        public MainForm()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
        }

        void GIM_Form_Closed(object sender, EventArgs e)
        {
            GIM_Form = null;
        }

        private void gIMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (GIM_Form == null)
            {
                GIM_Form = new GIMForm();
                GIM_Form.Closed += GIM_Form_Closed;
            }
            GIM_Form.MdiParent = this;
            GIM_Form.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(1);
        }
    }
}
