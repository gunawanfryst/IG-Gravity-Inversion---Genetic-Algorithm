﻿/*
 Name of code   : IG Gravity Inversion - Genetic Algorithm
 Version        : 1.7.3
 Developer      : Indra Gunawan
 Contact        : Teknik Geofisika, Institut Teknologi Bandung, Jl. Ganesha 10, BSC-B building, 2nd Floor, Dago, Bandung, Indonesia - 40132
 Phone          : (+62)853-551-88014 
 Email          : gunawan@geoph.itb.ac.id, gunawan.geoph@gmail.com
 Code Available : 01-01-2017  
 */

namespace IG.Class
{
    public class DataType_Class
    {
        public struct XYZ
        {
            public double x;
            public double y;
            public double z;
        }

        public struct XY
        {
            public double x;
            public double y;
        }

        public struct Bodies
        {
            public double x0;
            public double y0;
            public double z0;
            public double dx;
            public double dy;
            public double dz;
            public double rho;
        }

        public struct Response
        {
            public double x;
            public double y;
            public double z;
            public double grav;
        }

        public struct Report
        {
            public double misfit_total;
            public double misfit_data;
            public double misfit_model;
            public int nBodies;
            public Bodies[] model;
        }

    }
}
