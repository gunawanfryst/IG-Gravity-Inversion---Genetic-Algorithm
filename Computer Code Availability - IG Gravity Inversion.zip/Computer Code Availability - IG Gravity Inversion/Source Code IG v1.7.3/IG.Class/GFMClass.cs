﻿/*
 Name of code   : IG Gravity Inversion - Genetic Algorithm
 Version        : 1.7.3
 Developer      : Indra Gunawan
 Contact        : Teknik Geofisika, Institut Teknologi Bandung, Jl. Ganesha 10, BSC-B building, 2nd Floor, Dago, Bandung, Indonesia - 40132
 Phone          : (+62)853-551-88014 
 Email          : gunawan@geoph.itb.ac.id, gunawan.geoph@gmail.com
 Code Available : 01-01-2017  
 */

using System.Data;

namespace IG.Class
{
    public class GFMClass
    {
        public double[] Process(DataTable bodyDT, DataTable stationDT)
        {
            LibraryFunctionClass function = new LibraryFunctionClass();
            int nBodies = bodyDT.Rows.Count;
            DataType_Class.Bodies[] body = new DataType_Class.Bodies[nBodies];
            int nStation = stationDT.Rows.Count;
            DataType_Class.XYZ[] station = new DataType_Class.XYZ[nStation];

            for (int i=0; i<nBodies; i++)
            {
                body[i].x0 = double.Parse(bodyDT.Rows[i][1].ToString());
                body[i].y0 = double.Parse(bodyDT.Rows[i][2].ToString());
                body[i].z0 = double.Parse(bodyDT.Rows[i][3].ToString());
                body[i].dx = double.Parse(bodyDT.Rows[i][4].ToString());
                body[i].dy = double.Parse(bodyDT.Rows[i][5].ToString());
                body[i].dz = double.Parse(bodyDT.Rows[i][6].ToString());
                body[i].rho = double.Parse(bodyDT.Rows[i][7].ToString());
            }

            for (int i = 0; i < nStation; i++)
            {
                station[i].x = double.Parse(stationDT.Rows[i][1].ToString());
                station[i].y = double.Parse(stationDT.Rows[i][2].ToString());
                station[i].z = double.Parse(stationDT.Rows[i][3].ToString());
            }
            
            double[] response = function.okabe_GFM(body, station);

            return response;
        }
    }
}
