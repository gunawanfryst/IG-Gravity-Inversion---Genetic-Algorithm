﻿/*
 Name of code   : IG Gravity Inversion - Genetic Algorithm
 Version        : 1.7.3
 Developer      : Indra Gunawan
 Contact        : Teknik Geofisika, Institut Teknologi Bandung, Jl. Ganesha 10, BSC-B building, 2nd Floor, Dago, Bandung, Indonesia - 40132
 Phone          : (+62)853-551-88014 
 Email          : gunawan@geoph.itb.ac.id, gunawan.geoph@gmail.com
 Code Available : 01-01-2017  
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using IG.Class;
using ZedGraph;

namespace IG
{
    public partial class GIMForm : Form
    {
        DataTable BodiesDataTable = new DataTable();
        DataTable StationsDataTable = new DataTable();
        DataTable InitialModelDataTable = new DataTable();

        PointPairList listPointsOne = new PointPairList();
        PointPairList listPointsTwo = new PointPairList();
        PointPairList listPointsThree = new PointPairList();
        
        LibraryFunctionClass LF = new LibraryFunctionClass();

        public double dRho_1;
        public double dRho_2;
        double Axis_Y;

        public GIMForm()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            dRho_1 = double.Parse(dRho1textBox.Text);
            dRho_2 = double.Parse(dRho2textBox.Text);
            MenuSelectedcomboBox.SelectedIndex = 0;
            PilihTipeMutasicomboBox.SelectedIndex = 0;
            Axis_Y = double.Parse(Misfit_textBox.Text);
        }

        private void Process_button_Click(object sender, EventArgs e)
        {
            try
            {
                Process_button.Enabled = false;
                if (!Progress_backgroundWorker.IsBusy)
                {
                    string menu_selected = MenuSelectedcomboBox.Text;
                    string mutasi_selected = PilihTipeMutasicomboBox.Text;

                    string[] pilih = new string[] { menu_selected, mutasi_selected };
                    Progress_backgroundWorker.RunWorkerAsync(pilih);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Process Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BrowseBodies_button_Click(object sender, EventArgs e)
        {
            try
            {
                BrowseBodies_button.Enabled = false;
                OpenFileDialog openData = new OpenFileDialog();
                openData.Multiselect = true;
                openData.ShowDialog();
                openData.Filter = "dat-file (*.dat) | *.dat";

                if (openData.FileName != "")
                {
                    string fileName = openData.FileName;
                    BrowseBodies_textBox.Text = fileName;
                    DataTable dT = new DataTable();

                    DataColumn numbering = new DataColumn();
                    numbering.ColumnName = "No.";
                    numbering.DataType = typeof(int);
                    dT.Columns.Add(numbering);
                    dT.Columns["No."].SetOrdinal(0);

                    string[] lines = File.ReadAllLines(fileName);
                    string header = lines[0];
                    string[] headerName = header.Split('\t');

                    for (int i = 0; i < headerName.Length; i++)
                    {
                        string columnName = headerName[i];
                        dT.Columns.Add(columnName);
                    }

                    int counterRow = 0;
                    int number = 1;

                    foreach (var item in lines)
                    {
                        if (counterRow >= 1)
                        {
                            List<string> temp = new List<string>();
                            temp.Add(number.ToString());
                            string[] dataData = item.Split('\t');
                            foreach (string angka in dataData)
                            {
                                temp.Add(angka);
                            }
                            dT.Rows.Add(temp.ToArray());
                            number++;
                        }
                        counterRow++;
                    }
                    BodiesDataTable.Merge(dT);
                }

                BrowseBodies_button.Enabled = true;

                MinXtextBox.Text = BodiesDataTable.Rows[0].ItemArray[1].ToString();
                MinYtextBox.Text = BodiesDataTable.Rows[0].ItemArray[2].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error - Open Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BrowseStations_button_Click(object sender, EventArgs e)
        {
            try
            {
                BrowseStations_button.Enabled = false;
                OpenFileDialog openData = new OpenFileDialog();
                openData.Multiselect = true;
                openData.ShowDialog();
                openData.Filter = "allfiles|*";

                if (openData.FileName != "")
                {
                    string fileName = openData.FileName;
                    BrowseStations_textBox.Text = fileName;
                    DataTable dT = new DataTable();
                    DataColumn numbering = new DataColumn();
                    numbering.ColumnName = "No.";
                    numbering.DataType = typeof(int);
                    dT.Columns.Add(numbering);
                    dT.Columns["No."].SetOrdinal(0);

                    string[] lines = File.ReadAllLines(fileName);
                    string header = lines[0];
                    string[] headerName = header.Split('\t');

                    for (int i = 0; i < headerName.Length; i++)
                    {
                        string columnName = headerName[i];
                        dT.Columns.Add(columnName);
                    }

                    int counterRow = 0;
                    int number = 1;

                    foreach (var item in lines)
                    {
                        if (counterRow >= 1)
                        {
                            List<string> temp = new List<string>();
                            temp.Add(number.ToString());
                            string[] dataData = item.Split('\t');
                            foreach (string angka in dataData)
                            {
                                temp.Add(angka);
                            }
                            dT.Rows.Add(temp.ToArray());
                            number++;
                        }
                        counterRow++;
                    }
                    StationsDataTable.Merge(dT);
                }

                BrowseStations_button.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error - Open Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ExportToDatFile(double[] calc)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                saveFileDialog.Filter = "Data Files (*.dat)|*.dat|All Files (*.*)|*.*";

                if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
                {
                    string fileName = saveFileDialog.FileName;
                    StreamWriter sW = new StreamWriter(fileName);

                    string judul = "";
                    int counter = 0;
                    foreach (DataColumn kolom in BodiesDataTable.Columns)
                    {
                        if (counter > 0)
                        {
                            if (counter == 1)
                                judul += kolom.ColumnName.ToString();
                            else
                                judul += "\t" + kolom.ColumnName.ToString();
                        }
                        counter++;
                    }
                    judul += "\tcalc";
                    counter++;
                    sW.WriteLine(judul);

                    int baris = calc.Length;
                    for (int row = 0; row < baris; row++)
                    {
                        string lines = "";
                        for (int col = 1; col < counter; col++)
                        {
                            if (col == counter - 1)
                                lines += calc[row].ToString();
                            else
                                lines += BodiesDataTable.Rows[row][col].ToString() + "\t";
                        }
                        sW.WriteLine(lines);
                    }
                    sW.Close();
                    MessageBox.Show("Your data has been successfully saved!", "Save Output Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error - Export Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExportRMSDToDatFile(double[] rmsd)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                saveFileDialog.Filter = "Data Files (*.dat)|*.dat|All Files (*.*)|*.*";

                if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
                {
                    string fileName = saveFileDialog.FileName;
                    StreamWriter sW = new StreamWriter(fileName);

                    string judul = "No \t Iter \t rmsd";
                    sW.WriteLine(judul);

                    int baris = rmsd.Length;
                    for (int row = 0; row < baris; row++)
                    {
                        string lines = (row + 1).ToString() + "\t" + ((row+1)).ToString() + "\t" + rmsd[row].ToString();
                        sW.WriteLine(lines);
                    }
                    sW.Close();
                    MessageBox.Show("Your data has been successfully saved!", "Save Output Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error - Export Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void InitialModelBrowse_button_Click(object sender, EventArgs e)
        {
            try
            {
                InitialModelBrowse_button.Enabled = false;
                OpenFileDialog openData = new OpenFileDialog();
                openData.Multiselect = true;
                openData.ShowDialog();
                openData.Filter = "dat-file (*.dat) | *.dat";

                if (openData.FileName != "")
                {
                    string fileName = openData.FileName;
                    BrowseInitialModel_textBox.Text = fileName;
                    DataTable dT = new DataTable();

                    DataColumn numbering = new DataColumn();
                    numbering.ColumnName = "No.";
                    numbering.DataType = typeof(int);
                    dT.Columns.Add(numbering);
                    dT.Columns["No."].SetOrdinal(0);

                    string[] lines = File.ReadAllLines(fileName);
                    string header = lines[0];
                    string[] headerName = header.Split('\t');

                    for (int i = 0; i < headerName.Length; i++)
                    {
                        string columnName = headerName[i];
                        dT.Columns.Add(columnName);
                    }

                    int counterRow = 0;
                    int number = 1;

                    foreach (var item in lines)
                    {
                        if (counterRow >= 1)
                        {
                            List<string> temp = new List<string>();
                            temp.Add(number.ToString());
                            string[] dataData = item.Split('\t');
                            foreach (string angka in dataData)
                            {
                                temp.Add(angka);
                            }
                            dT.Rows.Add(temp.ToArray());
                            number++;
                        }
                        counterRow++;
                    }
                    InitialModelDataTable.Merge(dT);
                }

                InitialModelBrowse_button.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error - Open Data", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool[] DensityToBinary_1BIT(DataTable InitialModelDataTable)
        {
            LibraryFunctionClass LF = new LibraryFunctionClass();
            int length = InitialModelDataTable.Rows.Count;
            bool[] model_1_bit = new bool[length];
            for (int i = 0; i < length; i++)
            {
                if (double.Parse(InitialModelDataTable.Rows[i][7].ToString()) == dRho_2)
                {
                    model_1_bit[i] = true;
                }
                else
                {
                    model_1_bit[i] = false;
                }
            }
            return model_1_bit;
        }

        private void Progress_backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;
            string[] pilih = (string[])e.Argument;
            string menu_select = pilih[0];
            List<string> menu = (menu_select.Split(null)).ToList<string>();
            string menu_picked = menu[0];

            string mutasi_select = pilih[1];
            List<string> mutasi_menu = (mutasi_select.Split(null)).ToList<string>();
            string mutasi_picked = mutasi_menu[0];

            int k_mutasi = int.Parse(KMutationtextBox.Text);
            double beta = double.Parse(BetatextBox.Text);
            int max_iter = int.Parse(MaxItertextBox.Text);
            int nBodies = BodiesDataTable.Rows.Count;
            int nSta = StationsDataTable.Rows.Count;
            int nPanjang = int.Parse(nPanjang_textBox.Text);
            int nLebar = int.Parse(nLebar_textBox.Text);
            bool[] model_inisial_2_bit = new bool[nBodies * 2];
            bool[] model_inisial_1_bit = new bool[nBodies];
            if (nBodies != 0 && nSta != 0)
            {
                GIMClass GIM_Class = new GIMClass();
                int n_bit;
                if (menu_picked == "GA1")
                {
                    n_bit = 1;
                    model_inisial_1_bit = DensityToBinary_1BIT(InitialModelDataTable);
                    e.Result = GIM_Class.Process(BodiesDataTable, StationsDataTable, model_inisial_1_bit, InitialModelDataTable, worker, beta, dRho_1, dRho_2, menu_picked, n_bit, max_iter, mutasi_picked, k_mutasi, nPanjang, nLebar);
                }
            }
        }

        private void Progress_backgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            Iteration_textBox.Text = e.ProgressPercentage.ToString();
            DataType_Class.Report report = (DataType_Class.Report)e.UserState;
            Misfit_textBox.Text = report.misfit_total.ToString("00.00000");
            MisfitDataTextBox.Text = report.misfit_data.ToString("00.00000");
            MisfitModelTextBox.Text = report.misfit_model.ToString("00.00000");
            int nBodies = report.nBodies;

            DataType_Class.Bodies[] solution_map = new DataType_Class.Bodies[nBodies];
            solution_map = report.model;
            double v_axisY = double.Parse(Misfit_textBox.Text);
            double v_axisX = double.Parse(Iteration_textBox.Text);
            if (v_axisY > Axis_Y)
            {
                Axis_Y = v_axisY;
            }

            GraphPane myPane = new GraphPane();
            LineItem myCurve;
            myPane = misfit_zedGraphControl.GraphPane;
            myPane.CurveList.Clear();
            myPane.Title.Text = "misfit per-iterasi";
            myPane.XAxis.Scale.Min = 0.0;
            myPane.XAxis.Scale.Max = v_axisX + 1;
            myPane.YAxis.Scale.Min = 0.0;
            myPane.YAxis.Scale.Max = Axis_Y + 0.1 * Axis_Y;
            myPane.Legend.Position = ZedGraph.LegendPos.BottomCenter;
            listPointsOne.Add(double.Parse(Iteration_textBox.Text), double.Parse(Misfit_textBox.Text));
            listPointsTwo.Add(double.Parse(Iteration_textBox.Text), double.Parse(MisfitDataTextBox.Text));
            listPointsThree.Add(double.Parse(Iteration_textBox.Text), double.Parse(MisfitModelTextBox.Text));

            myCurve = myPane.AddCurve("misfit", listPointsOne, Color.Red, SymbolType.Circle);
            myCurve = myPane.AddCurve("data", listPointsTwo, Color.Blue, SymbolType.Plus);
            myCurve = myPane.AddCurve("model", listPointsThree, Color.Green, SymbolType.XCross);

            misfit_zedGraphControl.AxisChange();
            misfit_zedGraphControl.Refresh();
            misfit_zedGraphControl.Invalidate();

            //====================================MAP==============
            double dx = double.Parse(BodiesDataTable.Rows[0].ItemArray[4].ToString());
            double dy = double.Parse(BodiesDataTable.Rows[0].ItemArray[5].ToString());
            double minX = double.Parse(BodiesDataTable.Rows[0].ItemArray[1].ToString());
            double maxX = minX + double.Parse(nPanjang_textBox.Text) * dx;
            double minY = double.Parse(BodiesDataTable.Rows[0].ItemArray[2].ToString());
            double maxY = minY + double.Parse(nLebar_textBox.Text) * dy;

            PointPairList listPointsMap_rho1 = new PointPairList();
            PointPairList listPointsMap_rho2 = new PointPairList();
            PointPairList listPointsMap_rho3 = new PointPairList();
            PointPairList listPointsMap_rho4 = new PointPairList();
            for (int i = 0; i < solution_map.Length; i++)
            {
                if (solution_map[i].rho == dRho_1)
                {
                    listPointsMap_rho1.Add(solution_map[i].x0 + dx / 2, solution_map[i].y0 + dy/2, solution_map[i].rho);
                }
                else if (solution_map[i].rho == dRho_2)
                {
                    listPointsMap_rho2.Add(solution_map[i].x0 + dx / 2, solution_map[i].y0 + dy / 2, solution_map[i].rho);
                }
            }

            GraphPane mapPane = new GraphPane();
            LineItem mapCurve;
            mapPane = MapzedGraphControl.GraphPane;
            mapPane.CurveList.Clear();
            mapPane.Title.Text = "current solution";
            mapPane.XAxis.Scale.Min = minX;
            mapPane.XAxis.Scale.Max = maxX;
            mapPane.YAxis.Scale.Min = minY;
            mapPane.YAxis.Scale.Max = maxY;
            mapPane.XAxis.Scale.MajorStep = dx;
            mapPane.XAxis.Scale.MinorStep = dx;
            mapPane.YAxis.Scale.MajorStep = dy;
            mapPane.YAxis.Scale.MinorStep = dy;
            mapPane.Legend.Position = ZedGraph.LegendPos.BottomCenter;
            
            mapCurve = mapPane.AddCurve(dRho_1.ToString(), listPointsMap_rho1, Color.Green, SymbolType.Square);
            mapCurve.Line.IsVisible = false;
            mapCurve.Symbol.Size = 15.0F;
            mapCurve.Symbol.Fill = new Fill(Color.Green);
            mapCurve = mapPane.AddCurve(dRho_2.ToString(), listPointsMap_rho2, Color.GreenYellow, SymbolType.Square);
            mapCurve.Line.IsVisible = false;
            mapCurve.Symbol.Size = 15.0F;
            mapCurve.Symbol.Fill = new Fill(Color.GreenYellow);

            MapzedGraphControl.Refresh();
            MapzedGraphControl.Invalidate();

        }

        private void Progress_backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            MyResult result = (MyResult)e.Result;
            int nBodies = result.res.Length;
            int nSta = StationsDataTable.Rows.Count;
            double[] body = new double[nBodies];

            for (int i=0; i<nBodies; i++)
            {
                body[i] = result.res[i];
            }
            ExportToDatFile(body);
            ExportRMSDToDatFile(result.rmsd);
            int len = result.rmsd.Length;
            MessageBox.Show("Best misfit: " + result.rmsd[len-2].ToString() + "\nModel norm: " + result.rmsd[len - 1].ToString());
            Process_button.Enabled = true;
        }

        private void ChangedRhobutton_Click(object sender, EventArgs e)
        {
            dRho_1 = double.Parse(dRho1textBox.Text);
            dRho_2 = double.Parse(dRho2textBox.Text);
            MessageBox.Show("Your dRho value has been succesfully changed!");
        }

        private DataType_Class.Bodies[] convert_kambing_to_densitas_1_bit(DataType_Class.Bodies[] body, bool[] kambing_x)
        {
            int nBodies = body.Length;
            for (int i = 0; i < nBodies; i++)
            {
                int index = i;
                if (kambing_x[i] == true)
                    body[index].rho = dRho_2;
                else body[index].rho = dRho_1;
            }
            return body;
        }

        private void MenuSelectedcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string menu_select = MenuSelectedcomboBox.Text.ToString();
            List<string> menu = (menu_select.Split(null)).ToList<string>();
            string menu_picked = menu[0];
            switch (menu_picked)
            {
                case "GA1":
                    GAParams1GroupBox.Enabled = true;
                    GAParams2GroupBox.Enabled = true;
                    Iterationlabel.Enabled = true;
                    MaxItertextBox.Enabled = true;
                    Betalabel.Enabled = true;
                    BetatextBox.Enabled = true;
                    break;

                default:

                    break;
            }
        }
    }
}
