﻿/*
 Name of code   : IG Gravity Inversion - Genetic Algorithm
 Version        : 1.7.3
 Developer      : Indra Gunawan
 Contact        : Teknik Geofisika, Institut Teknologi Bandung, Jl. Ganesha 10, BSC-B building, 2nd Floor, Dago, Bandung, Indonesia - 40132
 Phone          : (+62)853-551-88014 
 Email          : gunawan@geoph.itb.ac.id, gunawan.geoph@gmail.com
 Code Available : 01-01-2017  
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using MathNet.Numerics.LinearAlgebra;

namespace IG.Class
{
    public class LibraryFunctionClass
    {
        public const double GRAV = 6.67384E-11 ;
        public  double dRho_1;
        public  double dRho_2;
        public const double alfa_s = 0;
        public const double alfa_xyz = 0.125;
        public const double misfit_GA = 1E-10;
        public const double misfit_LI = 1E-10;

        public const double top_limit = 0.12;
        public const double bot_limit = 0.0;
        
        private double rijk(double ai, double bj, double jk)
        {
            double res = Math.Sqrt(ai * ai + bj * bj + jk * jk);
            return res;
        }

        #region perhitungan misfit

        public double rmsd(DataType_Class.Response[] obs, double[] response)
        {
            int n = obs.Length;
            double res = 0;
            for (int i = 0; i < n; i++)
            {
                double w_data = 1;
                if (obs[i].z > 1)
                {
                    w_data = 1 / (obs[i].z * obs[i].z);
                }
                res = res + w_data * (obs[i].grav - response[i]) * (obs[i].grav - response[i]);
            }
            res = res / n;
            res = Math.Sqrt(res);
            return res;
        }

        private double model_obj(DataType_Class.Bodies[] body, int x, int y)
        {
            double res_total = 0;
            int nBodi = body.Length;
            DataType_Class.Bodies[,] body_xy = new DataType_Class.Bodies[x, y];
            int iter = 0;
            double res_v = 0;
            double w_v = alfa_s;
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    res_v += w_v * body[iter].dx * body[iter].dy * body[iter].dz * Math.Pow(body[iter].rho, 2);

                    body_xy[i, j].x0 = body[iter].x0;
                    body_xy[i, j].y0 = body[iter].y0;
                    body_xy[i, j].z0 = body[iter].z0;
                    body_xy[i, j].dx = body[iter].dx;
                    body_xy[i, j].dy = body[iter].dy;
                    body_xy[i, j].dz = body[iter].dz;
                    body_xy[i, j].rho = body[iter].rho;
                    iter++;
                }
            }

            double res = 0;
            for (int i = 1; i < x - 1; i++)
            {
                for (int j = 1; j < y - 1; j++)
                {
                    double w = alfa_xyz;
                    res += w * Math.Pow(body_xy[i, j].rho - body_xy[i + 1, j].rho, 2);
                    res += w * Math.Pow(body_xy[i, j].rho - body_xy[i - 1, j].rho, 2);
                    res += w * Math.Pow(body_xy[i, j].rho - body_xy[i, j + 1].rho, 2);
                    res += w * Math.Pow(body_xy[i, j].rho - body_xy[i, j - 1].rho, 2);
                    res += w * Math.Pow(body_xy[i, j].rho - body_xy[i - 1, j + 1].rho, 2);
                    res += w * Math.Pow(body_xy[i, j].rho - body_xy[i + 1, j + 1].rho, 2);
                    res += w * Math.Pow(body_xy[i, j].rho - body_xy[i - 1, j - 1].rho, 2);
                    res += w * Math.Pow(body_xy[i, j].rho - body_xy[i + 1, j - 1].rho, 2);
                }
            }
            res_total = res_v + res;
            return res_total;
        }

        #endregion

        #region deklarasi array

        private double[] zeros(int n)
        {
            double[] array = new double[n];
            for (int i = 0; i < n; i++)
            {
                array[i] = 0;
            }
            return array;
        }

        private bool[] falses(int n)
        {
            bool[] array = new bool[n];
            for (int i = 0; i < n; i++)
            {
                array[i] = false;
            }
            return array;
        }

        private bool[] trues(int n)
        {
            bool[] array = new bool[n];
            for (int i = 0; i < n; i++)
            {
                array[i] = true;
            }
            return array;
        }

        #endregion

        #region reproduksi

        private bool[] kawin(bool[] jantan, bool[] betina)
        {
            Random gen = new Random(Guid.NewGuid().GetHashCode());
            int n = jantan.Length;
            bool[] anak = falses(n);
            for (int i = 0; i < n; i++)
            {
                if (jantan[i] == true && betina[i] == true) anak[i] = true;
                else if (jantan[i] == false && betina[i] == false) anak[i] = false;
                else
                {
                    bool result = gen.Next(100) < 51 ? true : false;
                    anak[i] = result;
                }
            }
            return anak;
        }

        private bool[] full_rand_mutasi(bool[] kambing, int k_mutasi)
        {
            Random rnd = new Random(Guid.NewGuid().GetHashCode());
            int n = kambing.Length;
            bool[] hasil = new bool[n];
            hasil = kambing.Select(xx => xx).ToArray();
            int k = rnd.Next(1, k_mutasi);
            int s;
            for (int i = 0; i < k; i++)
            {
                s = rnd.Next(n);
                hasil[s] = !hasil[s];
            }
            return hasil;
        }

        private bool[] std_rand_mutasi(bool[] kambing, int k_mutasi)
        {
            Random rnd = new Random(Guid.NewGuid().GetHashCode());
            int n = kambing.Length;
            bool[] hasil = new bool[n];
            hasil = kambing.Select(xx => xx).ToArray();
            int k = k_mutasi;
            int s;
            for (int i = 0; i < k; i++)
            {
                s = rnd.Next(n);
                hasil[s] = !hasil[s];
            }
            return hasil;
        }

        private bool[] std_conv_mutasi(bool[] kambing, int k_mutasi)
        {
            Random rnd = new Random(Guid.NewGuid().GetHashCode());
            int n = kambing.Length;
            bool[] hasil = new bool[n];
            hasil = kambing.Select(xx => xx).ToArray();
            int k = k_mutasi;
            int start_pos = rnd.Next(0, n - k_mutasi);
            
            for (int i = start_pos; i < start_pos + k_mutasi + 1; i++)
            {
                hasil[i] = !hasil[i];
            }
            return hasil;
        }

        #endregion

        private DataType_Class.Bodies[] convert_kambing_to_densitas_1_bit(DataType_Class.Bodies[] body, bool[] kambing_x)
        {
            int nBodies = body.Length;
            for (int i = 0; i < nBodies; i++)
            {
                int index = i;
                if (kambing_x[i] == true)
                     body[index].rho = dRho_2;
                else body[index].rho = dRho_1;
            }
            return body;
        }

        public Matrix<double> okabe_kernel(DataType_Class.Bodies[] body, DataType_Class.XYZ[] station)
        {

            int nBodies = body.Length;
            int nStation = station.Length;
            Matrix<double> matrices = Matrix<double>.Build.Dense(nStation, nBodies);

            double[] res = zeros(nStation);

            for (int i = 0; i < nStation; i++)
            {
                double[] a = new double[2];
                double[] b = new double[2];
                double[] c = new double[2];
                double[] x = new double[2];
                double[] y = new double[2];
                double[] z = new double[2];

                for (int n = 0; n < nBodies; n++)
                {
                    double res_temp = 0;
                    a[0] = body[n].x0;
                    b[0] = body[n].y0;
                    c[0] = body[n].z0;
                    a[1] = body[n].x0 + body[n].dx;
                    b[1] = body[n].y0 + body[n].dy;
                    c[1] = body[n].z0 + body[n].dz;

                    for (int ii = 0; ii < 2; ii++)
                    {
                        for (int jj = 0; jj < 2; jj++)
                        {
                            for (int kk = 0; kk < 2; kk++)
                            {
                                x[ii] = station[i].x - a[ii];
                                y[jj] = station[i].y - b[jj];
                                z[kk] = station[i].z - c[kk];
                                double distance = rijk(x[ii], y[jj], z[kk]);
                                double nu_i;
                                if (ii == 0) nu_i = -1;
                                else nu_i = 1;
                                double nu_j;
                                if (jj == 0) nu_j = -1;
                                else nu_j = 1;
                                double nu_k;
                                if (kk == 0) nu_k = -1;
                                else nu_k = 1;
                                double nu = nu_i * nu_j * nu_k;
                                res_temp = res_temp + nu * (x[ii] * Math.Log(y[jj] + distance) + y[jj] * (Math.Log(x[ii] + distance)) + 2 * z[kk] * Math.Atan((x[ii] + y[jj] + distance) / (z[kk])));
                            }
                        }
                    };
                    matrices[i, n] = res_temp * -1 * GRAV * 1E11;
                }
            }
            return matrices;
        }

        public double[] okabe_GFM(DataType_Class.Bodies[] body, DataType_Class.XYZ[] station)
        {
            int nBodies = body.Length;
            int nStation = station.Length;
            double[] res = zeros(nStation);

            for (int i = 0; i < nStation; i++)
            {
                double[] a = new double[2];
                double[] b = new double[2];
                double[] c = new double[2];
                double[] x = new double[2];
                double[] y = new double[2];
                double[] z = new double[2];

                for (int n = 0; n < nBodies; n++)
                {
                    double res_temp = 0;
                    a[0] = body[n].x0;
                    b[0] = body[n].y0;
                    c[0] = body[n].z0;
                    a[1] = body[n].x0 + body[n].dx;
                    b[1] = body[n].y0 + body[n].dy; ;
                    c[1] = body[n].z0 + body[n].dz; ;

                    for (int ii = 0; ii < 2; ii++)
                    {
                        for (int jj = 0; jj < 2; jj++)
                        {
                            for (int kk = 0; kk < 2; kk++)
                            {
                                x[ii] = station[i].x - a[ii];
                                y[jj] = station[i].y - b[jj];
                                z[kk] = station[i].z - c[kk];
                                double distance = rijk(x[ii], y[jj], z[kk]);
                                double nu_i;
                                if (ii == 0) nu_i = -1;
                                else nu_i = 1;
                                double nu_j;
                                if (jj == 0) nu_j = -1;
                                else nu_j = 1;
                                double nu_k;
                                if (kk == 0) nu_k = -1;
                                else nu_k = 1;
                                double nu = nu_i * nu_j * nu_k;
                                res_temp = res_temp + nu * (x[ii] * Math.Log(y[jj] + distance) + y[jj] * (Math.Log(x[ii] + distance)) + 2 * z[kk] * Math.Atan((x[ii] + y[jj] + distance) / (z[kk])));
                            }
                        }
                    }
                    res[i] = res[i] + (body[n].rho * res_temp);
                }
                res[i] = res[i] * -1 * GRAV * 1E11;
            }
            return res;
        }

        public MyResult GA_GI_1BIT_V3(DataType_Class.Bodies[] body, DataType_Class.Response[] station, int n_populasi, int n_top_populasi, int n_mutasi, int k_panjang, int k_lebar, double lambda, bool[] model_inisial_1_bit, System.ComponentModel.BackgroundWorker backgroundWorker, double dRho1, double dRho2, int n_bit, int max_iterasi, string mutasi_picked, int k_mutasi)
        {
            dRho_1 = dRho1;
            dRho_2 = dRho2;
            int nBodies = body.Length;
            int nSta = station.Length;

            DataType_Class.XYZ[] stationXYZ = new DataType_Class.XYZ[nSta];
            for (int i = 0; i < nSta; i++)
            {
                stationXYZ[i].x = station[i].x;
                stationXYZ[i].y = station[i].y;
                stationXYZ[i].z = station[i].z;
            }

            int nKrom = body.Length;
            bool[] kambing_jantan = new bool[nKrom];
            bool[] kambing_betina = new bool[nKrom];

            if (model_inisial_1_bit.Length > 0)
            {
                kambing_jantan = model_inisial_1_bit.Select(xx => xx).ToArray();
            }
            else
            {
                kambing_jantan = trues(nKrom);
            }
            kambing_betina = falses(nKrom);

            //-------------UPDATE 4.1.1
            int n_new_gen = n_populasi - 2 * n_top_populasi;
            bool[][] kambing_top = new bool[n_top_populasi][];


            kambing_top[0] = kambing_jantan.Select(xx => xx).ToArray();
            kambing_top[1] = kambing_betina.Select(xx => xx).ToArray();
            for (int i = 2; i < n_top_populasi; i++)
            {
                kambing_top[i] = kawin(kambing_jantan, kambing_betina);
            }
            //-------------------------

            double best_rmsd = 0;
            List<double> log_rmsd = new List<double>();
            List<double> log_misfit_data = new List<double>();
            int iterasi = 0;
            int iterasi_log = 0;
            Random rnd = new Random();
            do
            {
                //-------------UPDATE 4.1.1
                bool[][] kambing_populasi = new bool[n_populasi][];
                for (int i = 0; i < n_new_gen; i++)
                {
                    int rnd_jantan, rnd_betina;
                    rnd_jantan = rnd.Next(n_top_populasi);
                    rnd_betina = rnd.Next(n_top_populasi);
                    kambing_populasi[i] = kawin(kambing_top[rnd_jantan], kambing_top[rnd_betina]);
                }

                int t_iter = 0;
                for (int i = n_new_gen; i < n_populasi - n_top_populasi; i++)
                {
                    bool[] temp = new bool[nKrom];
                    switch (mutasi_picked)
                    {
                        case "MU1":
                            std_conv_mutasi(kambing_top[t_iter], k_mutasi);
                            break;
                        case "MU2":
                            std_rand_mutasi(kambing_top[t_iter], k_mutasi);
                            break;
                        case "MU3":
                            full_rand_mutasi(kambing_top[t_iter], k_mutasi);
                            break;
                    }
                    kambing_populasi[i] = temp.Select(xx => xx).ToArray();

                    t_iter++;
                }

                t_iter = 0;
                for (int i = n_new_gen + n_top_populasi; i < n_populasi; i++)
                {
                    kambing_populasi[i] = kambing_top[t_iter].Select(xx => xx).ToArray();
                    t_iter++;
                }

                Array.Clear(kambing_top, 0, kambing_top.Length);

                double[] bobot = new double[n_populasi];
                double[] response = zeros(nSta);
                double[] t_misfit_data = new double[n_populasi];

                for (int i = 0; i < n_populasi; i++)
                {
                    DataType_Class.Bodies[] t_kambing = new DataType_Class.Bodies[nBodies];
                    t_kambing = convert_kambing_to_densitas_1_bit(body, kambing_populasi[i]);
                    response = okabe_GFM(t_kambing, stationXYZ);

                    double w_data = 1;
                    double w_model = lambda;
                    double misfit_data = w_data * rmsd(station, response);
                    double misfit_model = w_model * model_obj(t_kambing, k_panjang, k_lebar);

                    bobot[i] = misfit_data + misfit_model;
                    t_misfit_data[i] = misfit_data;
                }

                var sorted = bobot
                .Select((x, i) => new KeyValuePair<double, int>(x, i))
                .OrderBy(x => x.Key)
                .ToList();

                List<double> B = sorted.Select(x => x.Key).ToList();
                best_rmsd = B[0];
                List<int> idx = sorted.Select(x => x.Value).ToList();
                log_misfit_data.Add(t_misfit_data[idx[0]]);


                for (int i = 0; i < n_top_populasi; i++)
                {
                    kambing_top[i] = kambing_populasi[idx[i]].Select(xx => xx).ToArray();
                }

                for (int i = 0; i < n_top_populasi - 1; i++)
                {
                    for (int j = i + 1; j < n_top_populasi; j++)
                    {
                        if (kambing_top[i].SequenceEqual(kambing_top[j]))
                        {
                            bool[] temp = new bool[nKrom];
                            temp = full_rand_mutasi(kambing_top[j], k_mutasi);
                            kambing_top[j] = temp.Select(xx => xx).ToArray();
                        }
                    }
                }
                iterasi++;
                log_rmsd.Add(best_rmsd);
                iterasi_log++;

                //============REPORT
                DataType_Class.Report report = new DataType_Class.Report();
                DataType_Class.Bodies[] report_solution = new DataType_Class.Bodies[nBodies];

                report_solution = convert_kambing_to_densitas_1_bit(body, kambing_top[0]);
                double[] misfit = new double[3];
                var report_misfit_data = log_misfit_data[log_misfit_data.Count - 1];
                var report_misfit_model = best_rmsd - report_misfit_data;
                misfit[0] = best_rmsd;
                misfit[1] = report_misfit_data;
                misfit[2] = report_misfit_model;

                report.misfit_total = misfit[0];
                report.misfit_data = misfit[1];
                report.misfit_model = misfit[2];
                report.nBodies = nBodies;
                report.model = report_solution;

                backgroundWorker.ReportProgress(iterasi, report);

            } while (best_rmsd > misfit_GA && iterasi < max_iterasi);

            DataType_Class.Bodies[] solution = new DataType_Class.Bodies[nBodies];
            solution = convert_kambing_to_densitas_1_bit(solution, kambing_top[0]);
            double[] solution_array = new double[nBodies];
            for (int i = 0; i < nBodies; i++)
            {
                solution_array[i] = solution[i].rho;
            }

            return new MyResult { res = solution_array, rmsd = log_rmsd.ToArray(), iter = iterasi };
        }

        public Matrix<double> array_to_matrix(double[] array, int x, int y)
        {
            Matrix<double> matrices = Matrix<double>.Build.Dense(x, y);
            int count = 0;
            for (int i=0; i<x; i++)
            {
                for(int j=0; j<y; j++)
                {
                    matrices[x, y] = array[count];
                    count++;
                }
            }
            return matrices;
        }

        Vector<double> calc_neighbours_avg(Vector<double> matrix_input, int nBodi, int x, int y)
        {
            Vector<double> matrix_output = Vector<double>.Build.Dense(nBodi);
            double[,] matrix_temp = new double[x, y];
            int iter = 0;
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    matrix_temp[i, j] = matrix_input[iter];
                    iter++;
                }
            }

            iter = 0;
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    if (i == 0 && j == 0)
                        matrix_output[iter] = (matrix_temp[i, j] + matrix_temp[i, j + 1] + matrix_temp[i + 1, j] + matrix_temp[i+1, j+1]) / 4;
                    else if (i == 0 && j == y - 1)
                        matrix_output[iter] = (matrix_temp[i, j] + matrix_temp[i, j - 1] + matrix_temp[i + 1, j] + matrix_temp[i+1, j-1]) / 4;
                    else if (i == x - 1 && j == 0)
                        matrix_output[iter] = (matrix_temp[i, j] + matrix_temp[i, j + 1] + matrix_temp[i - 1, j] + matrix_temp[i-1, j+1]) / 4;
                    else if (i == x - 1 && j == y - 1)
                        matrix_output[iter] = (matrix_temp[i, j] + matrix_temp[i, j - 1] + matrix_temp[i - 1, j] + matrix_temp[i - 1, j - 1]) / 4;
                    else if (i == 0)
                        matrix_output[iter] = (matrix_temp[i, j] + matrix_temp[i, j + 1] + matrix_temp[i, j - 1] + matrix_temp[i + 1, j] + matrix_temp[i + 1, j + 1] + matrix_temp[i + 1, j - 1]) / 6;
                    else if (i == x - 1)
                        matrix_output[iter] = (matrix_temp[i, j] + matrix_temp[i, j + 1] + matrix_temp[i, j - 1] + matrix_temp[i - 1, j] + matrix_temp[i - 1, j + 1] + matrix_temp[i - 1, j - 1]) / 6;
                    else if (j == 0)
                        matrix_output[iter] = (matrix_temp[i, j] + matrix_temp[i + 1, j] + matrix_temp[i - 1, j] + matrix_temp[i, j + 1] + matrix_temp[i + 1, j + 1] + matrix_temp[i - 1, j + 1]) / 6;
                    else if (j == y - 1)
                        matrix_output[iter] = (matrix_temp[i, j] + matrix_temp[i + 1, j] + matrix_temp[i - 1, j] + matrix_temp[i, j - 1] + matrix_temp[i + 1, j - 1] + matrix_temp[i - 1, j - 1]) / 6;
                    else
                        matrix_output[iter] = (matrix_temp[i, j] + matrix_temp[i, j + 1] + matrix_temp[i, j - 1] + matrix_temp[i + 1, j] + matrix_temp[i + 1, j + 1] + matrix_temp[i + 1, j - 1] + matrix_temp[i - 1, j] + matrix_temp[i - 1, j + 1] + matrix_temp[i - 1, j - 1]) / 9;
                   
                    iter++;
                }
            }
            return matrix_output;
        }

    }

    #region tipe data hasil

    public class MyResult 
    {
        public double[] res { get; set; }
        public double[] rmsd { get; set; }
        public int iter { get; set; }
    }

    public class MyResultLI
    {
        public double[] res { get; set; }
        public double[] rmsd { get; set; }
        public int iter { get; set;}
    }

    public class MyResultLI_V3
    {
        public double[] res { get; set; }
        public double[] rmsd { get; set; }
        public Matrix<double> resol_data { get; set; }
        public Matrix<double> resol_model { get; set; }
        public Matrix<double> covar { get; set; }
        public int iter { get; set; }
    }

    #endregion
}
