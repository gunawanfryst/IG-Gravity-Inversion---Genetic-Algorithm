﻿namespace IG
{
    partial class GIMForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MinYtextBox = new System.Windows.Forms.TextBox();
            this.MinXtextBox = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.MisfitModelTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.MisfitDataTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Iteration_textBox = new System.Windows.Forms.TextBox();
            this.Misfit_textBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.Iterationlabel = new System.Windows.Forms.Label();
            this.MaxItertextBox = new System.Windows.Forms.TextBox();
            this.Betalabel = new System.Windows.Forms.Label();
            this.BetatextBox = new System.Windows.Forms.TextBox();
            this.MenuSelectedcomboBox = new System.Windows.Forms.ComboBox();
            this.GAParams2GroupBox = new System.Windows.Forms.GroupBox();
            this.PilihTipeMutasicomboBox = new System.Windows.Forms.ComboBox();
            this.KMutationtextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.GAParams1GroupBox = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dRho1textBox = new System.Windows.Forms.TextBox();
            this.dRho2textBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ChangedRhobutton = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.nLebar_textBox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.nPanjang_textBox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Process_button = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BrowseStations_button = new System.Windows.Forms.Button();
            this.BrowseStations_textBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BrowseBodies_button = new System.Windows.Forms.Button();
            this.BrowseBodies_textBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.InitialModelBrowse_button = new System.Windows.Forms.Button();
            this.BrowseInitialModel_textBox = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.misfit_zedGraphControl = new ZedGraph.ZedGraphControl();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.MapzedGraphControl = new ZedGraph.ZedGraphControl();
            this.Progress_backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.GAParams2GroupBox.SuspendLayout();
            this.GAParams1GroupBox.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox8);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox10);
            this.panel1.Controls.Add(this.GAParams2GroupBox);
            this.panel1.Controls.Add(this.GAParams1GroupBox);
            this.panel1.Controls.Add(this.groupBox7);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.Process_button);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 198);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1371, 176);
            this.panel1.TabIndex = 1;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label1);
            this.groupBox8.Controls.Add(this.MinYtextBox);
            this.groupBox8.Controls.Add(this.MinXtextBox);
            this.groupBox8.Location = new System.Drawing.Point(973, 122);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(273, 49);
            this.groupBox8.TabIndex = 35;
            this.groupBox8.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Min X,Y";
            // 
            // MinYtextBox
            // 
            this.MinYtextBox.Location = new System.Drawing.Point(189, 17);
            this.MinYtextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MinYtextBox.Name = "MinYtextBox";
            this.MinYtextBox.Size = new System.Drawing.Size(65, 22);
            this.MinYtextBox.TabIndex = 1;
            this.MinYtextBox.Text = "0.00000";
            this.MinYtextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // MinXtextBox
            // 
            this.MinXtextBox.Location = new System.Drawing.Point(115, 17);
            this.MinXtextBox.Margin = new System.Windows.Forms.Padding(4);
            this.MinXtextBox.Name = "MinXtextBox";
            this.MinXtextBox.Size = new System.Drawing.Size(65, 22);
            this.MinXtextBox.TabIndex = 0;
            this.MinXtextBox.Text = "0.00000";
            this.MinXtextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.MisfitModelTextBox);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.MisfitDataTextBox);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.Iteration_textBox);
            this.groupBox4.Controls.Add(this.Misfit_textBox);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Location = new System.Drawing.Point(11, 122);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(955, 49);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(485, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 17);
            this.label7.TabIndex = 9;
            this.label7.Text = "Model Norm";
            // 
            // MisfitModelTextBox
            // 
            this.MisfitModelTextBox.Location = new System.Drawing.Point(575, 14);
            this.MisfitModelTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MisfitModelTextBox.Name = "MisfitModelTextBox";
            this.MisfitModelTextBox.ReadOnly = true;
            this.MisfitModelTextBox.Size = new System.Drawing.Size(100, 22);
            this.MisfitModelTextBox.TabIndex = 8;
            this.MisfitModelTextBox.Text = "0.00000";
            this.MisfitModelTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(255, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 17);
            this.label6.TabIndex = 7;
            this.label6.Text = "Misfit Data";
            // 
            // MisfitDataTextBox
            // 
            this.MisfitDataTextBox.Location = new System.Drawing.Point(335, 14);
            this.MisfitDataTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MisfitDataTextBox.Name = "MisfitDataTextBox";
            this.MisfitDataTextBox.ReadOnly = true;
            this.MisfitDataTextBox.Size = new System.Drawing.Size(100, 22);
            this.MisfitDataTextBox.TabIndex = 6;
            this.MisfitDataTextBox.Text = "0.00000";
            this.MisfitDataTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(747, 16);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Iteration";
            // 
            // Iteration_textBox
            // 
            this.Iteration_textBox.Location = new System.Drawing.Point(813, 14);
            this.Iteration_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.Iteration_textBox.Name = "Iteration_textBox";
            this.Iteration_textBox.ReadOnly = true;
            this.Iteration_textBox.Size = new System.Drawing.Size(80, 22);
            this.Iteration_textBox.TabIndex = 3;
            this.Iteration_textBox.Text = "0";
            this.Iteration_textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Misfit_textBox
            // 
            this.Misfit_textBox.Location = new System.Drawing.Point(91, 14);
            this.Misfit_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.Misfit_textBox.Name = "Misfit_textBox";
            this.Misfit_textBox.ReadOnly = true;
            this.Misfit_textBox.Size = new System.Drawing.Size(105, 22);
            this.Misfit_textBox.TabIndex = 2;
            this.Misfit_textBox.Text = "0.00000";
            this.Misfit_textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Misfit Total";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox10.Controls.Add(this.Iterationlabel);
            this.groupBox10.Controls.Add(this.MaxItertextBox);
            this.groupBox10.Controls.Add(this.Betalabel);
            this.groupBox10.Controls.Add(this.BetatextBox);
            this.groupBox10.Controls.Add(this.MenuSelectedcomboBox);
            this.groupBox10.Location = new System.Drawing.Point(971, 6);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Size = new System.Drawing.Size(373, 114);
            this.groupBox10.TabIndex = 34;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "RUN";
            // 
            // Iterationlabel
            // 
            this.Iterationlabel.AutoSize = true;
            this.Iterationlabel.Location = new System.Drawing.Point(5, 20);
            this.Iterationlabel.Name = "Iterationlabel";
            this.Iterationlabel.Size = new System.Drawing.Size(59, 17);
            this.Iterationlabel.TabIndex = 20;
            this.Iterationlabel.Text = "Iteration";
            // 
            // MaxItertextBox
            // 
            this.MaxItertextBox.Location = new System.Drawing.Point(80, 17);
            this.MaxItertextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaxItertextBox.Name = "MaxItertextBox";
            this.MaxItertextBox.Size = new System.Drawing.Size(49, 22);
            this.MaxItertextBox.TabIndex = 19;
            this.MaxItertextBox.Text = "1000";
            this.MaxItertextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Betalabel
            // 
            this.Betalabel.AutoSize = true;
            this.Betalabel.Location = new System.Drawing.Point(5, 50);
            this.Betalabel.Name = "Betalabel";
            this.Betalabel.Size = new System.Drawing.Size(37, 17);
            this.Betalabel.TabIndex = 7;
            this.Betalabel.Text = "Beta";
            // 
            // BetatextBox
            // 
            this.BetatextBox.Location = new System.Drawing.Point(80, 48);
            this.BetatextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BetatextBox.Name = "BetatextBox";
            this.BetatextBox.Size = new System.Drawing.Size(49, 22);
            this.BetatextBox.TabIndex = 8;
            this.BetatextBox.Text = "1";
            this.BetatextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // MenuSelectedcomboBox
            // 
            this.MenuSelectedcomboBox.FormattingEnabled = true;
            this.MenuSelectedcomboBox.Items.AddRange(new object[] {
            "GA1 -  Genetic Algorithm 1 BIT"});
            this.MenuSelectedcomboBox.Location = new System.Drawing.Point(9, 79);
            this.MenuSelectedcomboBox.Margin = new System.Windows.Forms.Padding(4);
            this.MenuSelectedcomboBox.Name = "MenuSelectedcomboBox";
            this.MenuSelectedcomboBox.Size = new System.Drawing.Size(359, 24);
            this.MenuSelectedcomboBox.TabIndex = 18;
            this.MenuSelectedcomboBox.SelectedIndexChanged += new System.EventHandler(this.MenuSelectedcomboBox_SelectedIndexChanged);
            // 
            // GAParams2GroupBox
            // 
            this.GAParams2GroupBox.BackColor = System.Drawing.SystemColors.Control;
            this.GAParams2GroupBox.Controls.Add(this.PilihTipeMutasicomboBox);
            this.GAParams2GroupBox.Controls.Add(this.KMutationtextBox);
            this.GAParams2GroupBox.Controls.Add(this.label15);
            this.GAParams2GroupBox.Controls.Add(this.label16);
            this.GAParams2GroupBox.Location = new System.Drawing.Point(552, 6);
            this.GAParams2GroupBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GAParams2GroupBox.Name = "GAParams2GroupBox";
            this.GAParams2GroupBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GAParams2GroupBox.Size = new System.Drawing.Size(413, 114);
            this.GAParams2GroupBox.TabIndex = 33;
            this.GAParams2GroupBox.TabStop = false;
            this.GAParams2GroupBox.Text = "GA Mutation Parameter";
            // 
            // PilihTipeMutasicomboBox
            // 
            this.PilihTipeMutasicomboBox.FormattingEnabled = true;
            this.PilihTipeMutasicomboBox.Items.AddRange(new object[] {
            "MU1 - Standard Conventional Mutation",
            "MU2 - Standard Random Mutation",
            "MU3 - Full Random Mutation"});
            this.PilihTipeMutasicomboBox.Location = new System.Drawing.Point(88, 17);
            this.PilihTipeMutasicomboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PilihTipeMutasicomboBox.Name = "PilihTipeMutasicomboBox";
            this.PilihTipeMutasicomboBox.Size = new System.Drawing.Size(299, 24);
            this.PilihTipeMutasicomboBox.TabIndex = 24;
            // 
            // KMutationtextBox
            // 
            this.KMutationtextBox.Location = new System.Drawing.Point(88, 48);
            this.KMutationtextBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.KMutationtextBox.Name = "KMutationtextBox";
            this.KMutationtextBox.Size = new System.Drawing.Size(49, 22);
            this.KMutationtextBox.TabIndex = 22;
            this.KMutationtextBox.Text = "10";
            this.KMutationtextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(5, 50);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 17);
            this.label15.TabIndex = 23;
            this.label15.Text = "k Mutation";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(62, 17);
            this.label16.TabIndex = 25;
            this.label16.Text = "Mutation";
            // 
            // GAParams1GroupBox
            // 
            this.GAParams1GroupBox.BackColor = System.Drawing.SystemColors.Control;
            this.GAParams1GroupBox.Controls.Add(this.label9);
            this.GAParams1GroupBox.Controls.Add(this.dRho1textBox);
            this.GAParams1GroupBox.Controls.Add(this.dRho2textBox);
            this.GAParams1GroupBox.Controls.Add(this.label10);
            this.GAParams1GroupBox.Controls.Add(this.ChangedRhobutton);
            this.GAParams1GroupBox.Location = new System.Drawing.Point(175, 6);
            this.GAParams1GroupBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GAParams1GroupBox.Name = "GAParams1GroupBox";
            this.GAParams1GroupBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GAParams1GroupBox.Size = new System.Drawing.Size(372, 114);
            this.GAParams1GroupBox.TabIndex = 32;
            this.GAParams1GroupBox.TabStop = false;
            this.GAParams1GroupBox.Text = "GA Inversion Parameter";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 20);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 17);
            this.label9.TabIndex = 10;
            this.label9.Text = "d Rho 1";
            // 
            // dRho1textBox
            // 
            this.dRho1textBox.Location = new System.Drawing.Point(93, 17);
            this.dRho1textBox.Margin = new System.Windows.Forms.Padding(4);
            this.dRho1textBox.Name = "dRho1textBox";
            this.dRho1textBox.Size = new System.Drawing.Size(67, 22);
            this.dRho1textBox.TabIndex = 9;
            this.dRho1textBox.Text = "0.00";
            this.dRho1textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dRho2textBox
            // 
            this.dRho2textBox.Location = new System.Drawing.Point(93, 48);
            this.dRho2textBox.Margin = new System.Windows.Forms.Padding(4);
            this.dRho2textBox.Name = "dRho2textBox";
            this.dRho2textBox.Size = new System.Drawing.Size(67, 22);
            this.dRho2textBox.TabIndex = 11;
            this.dRho2textBox.Text = "0.5";
            this.dRho2textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 50);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 17);
            this.label10.TabIndex = 12;
            this.label10.Text = "d Rho 2";
            // 
            // ChangedRhobutton
            // 
            this.ChangedRhobutton.Location = new System.Drawing.Point(71, 80);
            this.ChangedRhobutton.Margin = new System.Windows.Forms.Padding(4);
            this.ChangedRhobutton.Name = "ChangedRhobutton";
            this.ChangedRhobutton.Size = new System.Drawing.Size(89, 28);
            this.ChangedRhobutton.TabIndex = 17;
            this.ChangedRhobutton.Text = "Change!";
            this.ChangedRhobutton.UseVisualStyleBackColor = true;
            this.ChangedRhobutton.Click += new System.EventHandler(this.ChangedRhobutton_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox7.Controls.Add(this.textBox1);
            this.groupBox7.Controls.Add(this.label19);
            this.groupBox7.Controls.Add(this.nLebar_textBox);
            this.groupBox7.Controls.Add(this.label17);
            this.groupBox7.Controls.Add(this.nPanjang_textBox);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Location = new System.Drawing.Point(11, 6);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox7.Size = new System.Drawing.Size(155, 114);
            this.groupBox7.TabIndex = 30;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "General Parameter";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(84, 79);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(45, 22);
            this.textBox1.TabIndex = 31;
            this.textBox1.Text = "1";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(7, 79);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(67, 17);
            this.label19.TabIndex = 30;
            this.label19.Text = "N Body Z";
            // 
            // nLebar_textBox
            // 
            this.nLebar_textBox.Location = new System.Drawing.Point(84, 48);
            this.nLebar_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.nLebar_textBox.Name = "nLebar_textBox";
            this.nLebar_textBox.Size = new System.Drawing.Size(45, 22);
            this.nLebar_textBox.TabIndex = 29;
            this.nLebar_textBox.Text = "20";
            this.nLebar_textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(7, 20);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 17);
            this.label17.TabIndex = 26;
            this.label17.Text = "N Body X";
            // 
            // nPanjang_textBox
            // 
            this.nPanjang_textBox.Location = new System.Drawing.Point(84, 17);
            this.nPanjang_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.nPanjang_textBox.Name = "nPanjang_textBox";
            this.nPanjang_textBox.Size = new System.Drawing.Size(45, 22);
            this.nPanjang_textBox.TabIndex = 28;
            this.nPanjang_textBox.Text = "20";
            this.nPanjang_textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(7, 50);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 17);
            this.label18.TabIndex = 27;
            this.label18.Text = "N Body Y";
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label4.Location = new System.Drawing.Point(0, 174);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1371, 2);
            this.label4.TabIndex = 5;
            // 
            // Process_button
            // 
            this.Process_button.Location = new System.Drawing.Point(1255, 127);
            this.Process_button.Margin = new System.Windows.Forms.Padding(4);
            this.Process_button.Name = "Process_button";
            this.Process_button.Size = new System.Drawing.Size(89, 39);
            this.Process_button.TabIndex = 4;
            this.Process_button.Text = "Process";
            this.Process_button.UseVisualStyleBackColor = true;
            this.Process_button.Click += new System.EventHandler(this.Process_button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BrowseStations_button);
            this.groupBox2.Controls.Add(this.BrowseStations_textBox);
            this.groupBox2.Location = new System.Drawing.Point(11, 132);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1333, 55);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Obs Stations";
            // 
            // BrowseStations_button
            // 
            this.BrowseStations_button.Location = new System.Drawing.Point(1129, 17);
            this.BrowseStations_button.Margin = new System.Windows.Forms.Padding(4);
            this.BrowseStations_button.Name = "BrowseStations_button";
            this.BrowseStations_button.Size = new System.Drawing.Size(89, 28);
            this.BrowseStations_button.TabIndex = 2;
            this.BrowseStations_button.Text = "Browse";
            this.BrowseStations_button.UseVisualStyleBackColor = true;
            this.BrowseStations_button.Click += new System.EventHandler(this.BrowseStations_button_Click);
            // 
            // BrowseStations_textBox
            // 
            this.BrowseStations_textBox.Location = new System.Drawing.Point(7, 21);
            this.BrowseStations_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.BrowseStations_textBox.Name = "BrowseStations_textBox";
            this.BrowseStations_textBox.Size = new System.Drawing.Size(1112, 22);
            this.BrowseStations_textBox.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BrowseBodies_button);
            this.groupBox1.Controls.Add(this.BrowseBodies_textBox);
            this.groupBox1.Location = new System.Drawing.Point(11, 68);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1333, 55);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bodies Template";
            // 
            // BrowseBodies_button
            // 
            this.BrowseBodies_button.Location = new System.Drawing.Point(1129, 16);
            this.BrowseBodies_button.Margin = new System.Windows.Forms.Padding(4);
            this.BrowseBodies_button.Name = "BrowseBodies_button";
            this.BrowseBodies_button.Size = new System.Drawing.Size(89, 28);
            this.BrowseBodies_button.TabIndex = 1;
            this.BrowseBodies_button.Text = "Browse";
            this.BrowseBodies_button.UseVisualStyleBackColor = true;
            this.BrowseBodies_button.Click += new System.EventHandler(this.BrowseBodies_button_Click);
            // 
            // BrowseBodies_textBox
            // 
            this.BrowseBodies_textBox.Location = new System.Drawing.Point(7, 20);
            this.BrowseBodies_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.BrowseBodies_textBox.Name = "BrowseBodies_textBox";
            this.BrowseBodies_textBox.Size = new System.Drawing.Size(1112, 22);
            this.BrowseBodies_textBox.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1371, 198);
            this.panel2.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.InitialModelBrowse_button);
            this.groupBox3.Controls.Add(this.BrowseInitialModel_textBox);
            this.groupBox3.Location = new System.Drawing.Point(11, 4);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(1333, 55);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Initial Model (optional)";
            // 
            // InitialModelBrowse_button
            // 
            this.InitialModelBrowse_button.Location = new System.Drawing.Point(1129, 17);
            this.InitialModelBrowse_button.Margin = new System.Windows.Forms.Padding(4);
            this.InitialModelBrowse_button.Name = "InitialModelBrowse_button";
            this.InitialModelBrowse_button.Size = new System.Drawing.Size(89, 28);
            this.InitialModelBrowse_button.TabIndex = 1;
            this.InitialModelBrowse_button.Text = "Browse";
            this.InitialModelBrowse_button.UseVisualStyleBackColor = true;
            this.InitialModelBrowse_button.Click += new System.EventHandler(this.InitialModelBrowse_button_Click);
            // 
            // BrowseInitialModel_textBox
            // 
            this.BrowseInitialModel_textBox.Location = new System.Drawing.Point(7, 21);
            this.BrowseInitialModel_textBox.Margin = new System.Windows.Forms.Padding(4);
            this.BrowseInitialModel_textBox.Name = "BrowseInitialModel_textBox";
            this.BrowseInitialModel_textBox.Size = new System.Drawing.Size(1112, 22);
            this.BrowseInitialModel_textBox.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.groupBox5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 374);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(638, 332);
            this.panel3.TabIndex = 3;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.misfit_zedGraphControl);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox5.Location = new System.Drawing.Point(0, 0);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(638, 332);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            // 
            // misfit_zedGraphControl
            // 
            this.misfit_zedGraphControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.misfit_zedGraphControl.Location = new System.Drawing.Point(4, 19);
            this.misfit_zedGraphControl.Margin = new System.Windows.Forms.Padding(5);
            this.misfit_zedGraphControl.Name = "misfit_zedGraphControl";
            this.misfit_zedGraphControl.ScrollGrace = 0D;
            this.misfit_zedGraphControl.ScrollMaxX = 0D;
            this.misfit_zedGraphControl.ScrollMaxY = 0D;
            this.misfit_zedGraphControl.ScrollMaxY2 = 0D;
            this.misfit_zedGraphControl.ScrollMinX = 0D;
            this.misfit_zedGraphControl.ScrollMinY = 0D;
            this.misfit_zedGraphControl.ScrollMinY2 = 0D;
            this.misfit_zedGraphControl.Size = new System.Drawing.Size(630, 309);
            this.misfit_zedGraphControl.TabIndex = 5;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.groupBox6);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(638, 374);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(733, 332);
            this.panel4.TabIndex = 4;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.MapzedGraphControl);
            this.groupBox6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox6.Location = new System.Drawing.Point(0, 0);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Size = new System.Drawing.Size(733, 332);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Current Solution";
            // 
            // MapzedGraphControl
            // 
            this.MapzedGraphControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MapzedGraphControl.Location = new System.Drawing.Point(3, 17);
            this.MapzedGraphControl.Margin = new System.Windows.Forms.Padding(5);
            this.MapzedGraphControl.Name = "MapzedGraphControl";
            this.MapzedGraphControl.ScrollGrace = 0D;
            this.MapzedGraphControl.ScrollMaxX = 0D;
            this.MapzedGraphControl.ScrollMaxY = 0D;
            this.MapzedGraphControl.ScrollMaxY2 = 0D;
            this.MapzedGraphControl.ScrollMinX = 0D;
            this.MapzedGraphControl.ScrollMinY = 0D;
            this.MapzedGraphControl.ScrollMinY2 = 0D;
            this.MapzedGraphControl.Size = new System.Drawing.Size(727, 313);
            this.MapzedGraphControl.TabIndex = 6;
            // 
            // Progress_backgroundWorker
            // 
            this.Progress_backgroundWorker.WorkerReportsProgress = true;
            this.Progress_backgroundWorker.WorkerSupportsCancellation = true;
            this.Progress_backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Progress_backgroundWorker_DoWork);
            this.Progress_backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.Progress_backgroundWorker_ProgressChanged);
            this.Progress_backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.Progress_backgroundWorker_RunWorkerCompleted);
            // 
            // GIMForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1371, 706);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "GIMForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "GIM";
            this.panel1.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.GAParams2GroupBox.ResumeLayout(false);
            this.GAParams2GroupBox.PerformLayout();
            this.GAParams1GroupBox.ResumeLayout(false);
            this.GAParams1GroupBox.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Process_button;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BrowseStations_button;
        private System.Windows.Forms.TextBox BrowseStations_textBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BrowseBodies_button;
        private System.Windows.Forms.TextBox BrowseBodies_textBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button InitialModelBrowse_button;
        private System.Windows.Forms.TextBox BrowseInitialModel_textBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Iteration_textBox;
        private System.Windows.Forms.TextBox Misfit_textBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.ComponentModel.BackgroundWorker Progress_backgroundWorker;
        private System.Windows.Forms.GroupBox groupBox5;
        private ZedGraph.ZedGraphControl misfit_zedGraphControl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox MisfitModelTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox MisfitDataTextBox;
        private System.Windows.Forms.GroupBox groupBox6;
        private ZedGraph.ZedGraphControl MapzedGraphControl;
        private System.Windows.Forms.TextBox BetatextBox;
        private System.Windows.Forms.Label Betalabel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox dRho2textBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox dRho1textBox;
        private System.Windows.Forms.Button ChangedRhobutton;
        private System.Windows.Forms.ComboBox MenuSelectedcomboBox;
        private System.Windows.Forms.Label Iterationlabel;
        private System.Windows.Forms.TextBox MaxItertextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox KMutationtextBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox PilihTipeMutasicomboBox;
        private System.Windows.Forms.TextBox nLebar_textBox;
        private System.Windows.Forms.TextBox nPanjang_textBox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox GAParams1GroupBox;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox GAParams2GroupBox;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox MinYtextBox;
        private System.Windows.Forms.TextBox MinXtextBox;
    }
}